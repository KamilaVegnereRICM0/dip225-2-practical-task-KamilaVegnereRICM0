import pandas
fails = pandas.read_excel('description.xlsx', sheet_name='LookupAREA')
info_list = fails.values.tolist()
get_info=input('') 
region_code=0
for row in info_list:
    if row[1]==get_info:
        region_code=row[0]
        break
region_code
if region_code==0:
    print(0)
    exit()
CleanData=[]
csvdati=open('data.csv','r')
for line in csvdati:
    CleanData.append(line.rstrip().split(','))
geo_count=[]
for line in CleanData:
    if line[1]==region_code:
        geo_count.append(int(line[3]))
print(sum(geo_count))